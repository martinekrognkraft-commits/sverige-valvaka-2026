# No shrinking in v3.0. Kept for future release builds.
