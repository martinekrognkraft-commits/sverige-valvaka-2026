package se.valvaka;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String APP_URL = "http://127.0.0.1:8765/";
    private static final String ASSET_VERSION = "3.0.0";

    private WebView webView;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 31));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 17, 31));
        setContentView(webView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(settings.getUserAgentString() + " SverigeValvaka/3.0");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host == null || "127.0.0.1".equals(host) || "localhost".equals(host)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        showLoading("Startar Sverige Valvaka 2026…");
        worker.execute(this::startBackendAndOpen);
    }

    private void startBackendAndOpen() {
        try {
            File runtime = new File(getFilesDir(), "valvaka");
            prepareBundledAssets(runtime);

            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            Python py = Python.getInstance();
            PyObject server = py.getModule("mobile_server");
            server.callAttr("start_server", runtime.getAbsolutePath());

            if (!waitForServer(30000)) {
                throw new IOException("Den lokala Valvaka-servern svarade inte inom 30 sekunder.");
            }
            runOnUiThread(() -> webView.loadUrl(APP_URL));
        } catch (Throwable e) {
            String msg = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            runOnUiThread(() -> showError(msg));
        }
    }

    private void prepareBundledAssets(File runtime) throws IOException {
        File staticDir = new File(runtime, "static");
        File geoDir = new File(runtime, "data/geo");
        String installed = getPreferences(MODE_PRIVATE).getString("asset_version", "");

        if (!ASSET_VERSION.equals(installed) || !new File(geoDir, "meta.json").isFile()) {
            deleteRecursively(staticDir);
            deleteRecursively(geoDir);
            copyAssetTree("www", staticDir);
            copyAssetTree("geo", geoDir);
            getPreferences(MODE_PRIVATE).edit().putString("asset_version", ASSET_VERSION).apply();
        }
        File dataDir = new File(runtime, "data");
        if (!dataDir.exists() && !dataDir.mkdirs()) {
            throw new IOException("Kunde inte skapa appens datamapp.");
        }
    }

    private void copyAssetTree(String assetPath, File target) throws IOException {
        String[] children = getAssets().list(assetPath);
        if (children == null) {
            children = new String[0];
        }
        if (children.length == 0) {
            File parent = target.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("Kunde inte skapa " + parent);
            }
            try (InputStream in = getAssets().open(assetPath);
                 FileOutputStream out = new FileOutputStream(target)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            return;
        }

        if (!target.exists() && !target.mkdirs()) {
            throw new IOException("Kunde inte skapa " + target);
        }
        for (String child : children) {
            copyAssetTree(assetPath + "/" + child, new File(target, child));
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursively(child);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private boolean waitForServer(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL("http://127.0.0.1:8765/api/bootstrap").openConnection();
                conn.setConnectTimeout(800);
                conn.setReadTimeout(800);
                conn.setUseCaches(false);
                if (conn.getResponseCode() == 200) return true;
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    private void showLoading(String text) {
        String html = "<!doctype html><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                "<body style=\"margin:0;background:#07111f;color:white;font-family:sans-serif;display:grid;place-items:center;height:100vh\">" +
                "<div style=\"text-align:center\"><div style=\"font-size:22px;font-weight:700;margin-bottom:10px\">Sverige Valvaka 2026</div>" +
                "<div style=\"opacity:.7;font-size:15px\">" + text + "</div></div></body>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void showError(String message) {
        TextView view = new TextView(this);
        view.setText("Sverige Valvaka kunde inte starta.\n\n" + message + "\n\nStäng appen helt och försök igen.");
        view.setTextColor(Color.WHITE);
        view.setTextSize(16);
        view.setPadding(48, 48, 48, 48);
        view.setGravity(android.view.Gravity.CENTER);
        view.setBackgroundColor(Color.rgb(7, 17, 31));
        setContentView(view);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null && webView.getUrl() != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
