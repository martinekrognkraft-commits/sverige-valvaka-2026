# Sverige Valvaka 2026 — Android

En fristående Android-version av Sverige Valvaka 2026.

## Funktioner

- Live-resultat från Valmyndighetens officiella 2026-resultatfiler.
- Automatisk kontroll var 60:e sekund.
- Sverigevy med alla 290 kommungränser och tydliga länsgränser.
- Tryck på län → kommuner.
- Tryck på kommun → valdistrikt.
- Tryck på valdistrikt → detaljruta, utan ytterligare kartzoom.
- Kommuner färgas så snart minst ett valdistrikt har rapporterat.
- Valdistrikt färgas när distriktet är färdigräknat.
- Resultat, mandat och räknade distrikt i nederpanelen.
- ÖVR ingår i procentberäkningen men behandlas inte som ett enda mandatparti.
- Touch- och mobilanpassad layout.

## Android-arkitektur

Appen använder en WebView för det befintliga kartgränssnittet och en liten lokal Python-server via Chaquopy. Servern lyssnar endast på `127.0.0.1` inne i telefonen.

Kartgeometrin byggs **vid GitHub Actions-bygget** från Valmyndighetens GIS-fil och bäddas in i APK:n. Telefonen behöver därför inte installera Shapely, pyproj, Termux eller Flask.

## Datakälla

Källa: Valmyndigheten.

Resultat:
`https://resultat.val.se/resultatfiler/val2026/`

GIS:
`https://www.val.se/valresultat-och-statistik/statistik-och-data/radata-val-2026`

## Bygga APK

GitHub Actions-workflowen `.github/workflows/build-apk.yml` körs automatiskt vid push till `main`.

När bygget är klart:

1. Öppna **Actions** i GitHub.
2. Öppna senaste **Build Android APK**.
3. Ladda ner artifact **Sverige-Valvaka-2026-APK**.
4. Packa upp artifact-ZIP:en på Android.
5. Installera `Sverige-Valvaka-2026-v3.1-debug.apk`.

Android kan första gången fråga om tillåtelse att installera appar från Chrome/Files.

## Mål

Första APK-versionen är arm64-only och riktad mot moderna Android-telefoner, inklusive Xiaomi 15 Ultra.
