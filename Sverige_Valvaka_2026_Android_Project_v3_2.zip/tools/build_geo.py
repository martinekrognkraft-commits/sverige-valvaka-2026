#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import tempfile
import time
import unicodedata
import urllib.request
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from pyproj import Transformer
from shapely.geometry import box, mapping, shape
from shapely.ops import transform as shp_transform, unary_union

GIS_ZIP_URL = "https://www.val.se/download/18.332cf48819bd61ac1513889/1785491689960/valdistrikt-riket-2026.zip"
LAKES_ZIP_URL = "https://naturalearth.s3.amazonaws.com/10m_physical/ne_10m_lakes.zip"

COUNTY_NAMES = {
    "01": "Stockholms län", "03": "Uppsala län", "04": "Södermanlands län",
    "05": "Östergötlands län", "06": "Jönköpings län", "07": "Kronobergs län",
    "08": "Kalmar län", "09": "Gotlands län", "10": "Blekinge län", "12": "Skåne län",
    "13": "Hallands län", "14": "Västra Götalands län", "17": "Värmlands län",
    "18": "Örebro län", "19": "Västmanlands län", "20": "Dalarnas län",
    "21": "Gävleborgs län", "22": "Västernorrlands län", "23": "Jämtlands län",
    "24": "Västerbottens län", "25": "Norrbottens län",
}


def norm(s: Any) -> str:
    text = str(s or "").strip().lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]", "", text)


def first_prop(props: dict[str, Any], candidates: Iterable[str]) -> Any:
    wanted = {norm(x) for x in candidates}
    for k, v in props.items():
        if norm(k) in wanted and v not in (None, ""):
            return v
    return None


def fuzzy_prop(props: dict[str, Any], includes: Iterable[str], excludes: Iterable[str] = ()) -> Any:
    inc = [norm(x) for x in includes]
    exc = [norm(x) for x in excludes]
    for k, v in props.items():
        nk = norm(k)
        if all(x in nk for x in inc) and not any(x in nk for x in exc) and v not in (None, ""):
            return v
    return None


def extract_district_code(props: dict[str, Any]) -> str | None:
    val = first_prop(props, [
        "valdistriktskod", "valdistriktkod", "vdistrkod", "vdistkod", "kod_2026",
        "valdistriktskod 2026", "id"
    ])
    if val is not None:
        m = re.search(r"(?<!\d)(\d{8})(?!\d)", str(val))
        if m:
            return m.group(1)
    for v in props.values():
        m = re.fullmatch(r"\s*(\d{8})\s*", str(v))
        if m:
            return m.group(1)
    return None


def extract_names(props: dict[str, Any], code: str) -> tuple[str, str, str]:
    dname = first_prop(props, ["valdistriktsnamn", "valdistrikt", "vdistrnamn", "namn"])
    if not dname:
        dname = fuzzy_prop(props, ["valdistr", "namn"])
    mname = first_prop(props, ["kommunnamn", "kommun", "kommun namn"])
    if not mname:
        mname = fuzzy_prop(props, ["kommun"], ["kod", "valkrets"])
    lname = first_prop(props, ["lansnamn", "länsnamn", "lan", "län", "lan namn"])
    if not lname:
        lname = fuzzy_prop(props, ["lan"], ["kod", "valkrets"])
    return (
        str(dname or f"Valdistrikt {code}"),
        str(mname or f"Kommun {code[:4]}"),
        str(lname or COUNTY_NAMES.get(code[:2], f"Län {code[:2]}")),
    )


def iter_features(obj: Any):
    if isinstance(obj, dict):
        if obj.get("type") == "FeatureCollection" and isinstance(obj.get("features"), list):
            yield from obj["features"]
            return
        if obj.get("type") == "Feature" and "geometry" in obj:
            yield obj
            return
        for v in obj.values():
            yield from iter_features(v)
    elif isinstance(obj, list):
        for x in obj:
            yield from iter_features(x)


def download(url: str, dst: Path):
    print(f"[geo] Downloading {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "Sverige-Valvaka-2026-GitHub-Actions/1.0"})
    with urllib.request.urlopen(req, timeout=180) as r, dst.open("wb") as f:
        while True:
            chunk = r.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)
    print(f"[geo] Downloaded {dst.stat().st_size / 1024 / 1024:.1f} MB")



def label_point(geom):
    """Return a stable point inside the largest polygon component for map labels."""
    try:
        target = geom
        if getattr(geom, "geom_type", "") == "MultiPolygon":
            target = max(geom.geoms, key=lambda g: g.area)
        pt = target.representative_point()
        return float(pt.x), float(pt.y)
    except Exception:
        c = geom.centroid
        return float(c.x), float(c.y)


def build_water(out_dir: Path, temp_dir: Path):
    """Build a lightweight lake mask used only for orientation.

    Natural Earth 1:10m provides the larger lakes. The normal OSM raster remains
    visible as a faint overlay, so smaller lakes/roads/place names still help.
    """
    try:
        import shapefile  # pyshp
        lake_zip = temp_dir / "ne_10m_lakes.zip"
        download(LAKES_ZIP_URL, lake_zip)
        extract_dir = temp_dir / "lakes"
        extract_dir.mkdir(exist_ok=True)
        with zipfile.ZipFile(lake_zip) as zf:
            zf.extractall(extract_dir)
        shp_files = list(extract_dir.glob("*.shp"))
        if not shp_files:
            raise RuntimeError("Natural Earth ZIP saknar .shp")

        reader = shapefile.Reader(str(shp_files[0]))
        fields = [f[0] for f in reader.fields[1:]]
        sweden_window = box(10.0, 54.0, 25.5, 70.5)
        features = []
        for sr in reader.iterShapeRecords():
            try:
                geom = shape(sr.shape.__geo_interface__)
                if geom.is_empty or not geom.intersects(sweden_window):
                    continue
                geom = geom.intersection(sweden_window)
                if geom.geom_type not in ("Polygon", "MultiPolygon"):
                    continue
                # Tiny Natural Earth polygons do not help orientation and cost APK size.
                if geom.area < 0.00004:
                    continue
                geom = geom.simplify(0.00045, preserve_topology=True)
                record = dict(zip(fields, list(sr.record)))
                features.append({
                    "type": "Feature",
                    "properties": {
                        "name": str(record.get("name") or record.get("name_en") or "Sjö"),
                        "scale_rank": record.get("scalerank", record.get("scale_rank", 99)),
                    },
                    "geometry": mapping(geom),
                })
            except Exception:
                continue
        (out_dir / "water.geojson").write_text(
            json.dumps({"type":"FeatureCollection","features":features}, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )
        print(f"[geo] Built water mask with {len(features)} lake features")
    except Exception as e:
        # Water is an orientation enhancement, never a reason to fail the APK build.
        print("[geo] WARNING: water mask could not be built:", e)
        (out_dir / "water.geojson").write_text('{"type":"FeatureCollection","features":[]}', encoding="utf-8")


def build(out_dir: Path, zip_path: Path, temp_dir: Path | None = None):
    out_dir.mkdir(parents=True, exist_ok=True)
    districts_dir = out_dir / "districts"
    municipalities_dir = out_dir / "municipalities"
    districts_dir.mkdir(exist_ok=True)
    municipalities_dir.mkdir(exist_ok=True)

    transformer = Transformer.from_crs("EPSG:3006", "EPSG:4326", always_xy=True)

    district_features_by_muni: dict[str, list[dict[str, Any]]] = defaultdict(list)
    muni_geoms: dict[str, list[Any]] = defaultdict(list)
    county_geoms: dict[str, list[Any]] = defaultdict(list)
    muni_names: dict[str, str] = {}
    county_names: dict[str, str] = {}
    district_codes_by_muni: dict[str, list[str]] = defaultdict(list)

    found = 0
    with zipfile.ZipFile(zip_path) as zf:
        names = [n for n in zf.namelist() if n.lower().endswith((".json", ".geojson"))]
        if not names:
            raise RuntimeError("GIS ZIP contains no JSON/GeoJSON file")
        for name in names:
            print("[geo] Reading", name)
            try:
                raw = json.loads(zf.read(name).decode("utf-8-sig"))
            except Exception as e:
                print("[geo] Skipping", name, e)
                continue
            for feat in iter_features(raw):
                props = feat.get("properties") or {}
                code = extract_district_code(props)
                geom_obj = feat.get("geometry")
                if not code or not geom_obj:
                    continue
                try:
                    geom = shape(geom_obj)
                    geom = shp_transform(transformer.transform, geom)
                    if not geom.is_valid:
                        geom = geom.buffer(0)
                    if geom.is_empty:
                        continue
                except Exception:
                    continue

                dname, mname, lname = extract_names(props, code)
                mcode, lcode = code[:4], code[:2]
                muni_names.setdefault(mcode, mname)
                county_names.setdefault(lcode, lname)
                district_codes_by_muni[mcode].append(code)
                muni_geoms[mcode].append(geom)
                county_geoms[lcode].append(geom)

                dgeom = geom.simplify(0.00012, preserve_topology=True)
                label_lon, label_lat = label_point(dgeom)
                district_features_by_muni[mcode].append({
                    "type": "Feature",
                    "properties": {
                        "code": code,
                        "name": dname,
                        "municipality_code": mcode,
                        "municipality_name": mname,
                        "county_code": lcode,
                        "county_name": lname,
                        "label_lon": label_lon,
                        "label_lat": label_lat,
                    },
                    "geometry": mapping(dgeom),
                })
                found += 1

    if found < 1000:
        raise RuntimeError(f"Only parsed {found} districts")

    def dump(path: Path, obj: Any):
        path.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    for mcode, feats in district_features_by_muni.items():
        dump(districts_dir / f"{mcode}.geojson", {"type": "FeatureCollection", "features": feats})

    munis_by_county: dict[str, list[dict[str, Any]]] = defaultdict(list)
    all_muni_features: list[dict[str, Any]] = []
    for mcode, geoms in muni_geoms.items():
        merged = unary_union(geoms)
        if not merged.is_valid:
            merged = merged.buffer(0)
        merged = merged.simplify(0.00045, preserve_topology=True)
        lcode = mcode[:2]
        label_lon, label_lat = label_point(merged)
        feat = {
            "type": "Feature",
            "properties": {
                "code": mcode,
                "name": muni_names.get(mcode, f"Kommun {mcode}"),
                "county_code": lcode,
                "county_name": county_names.get(lcode, COUNTY_NAMES.get(lcode, f"Län {lcode}")),
                "district_count": len(set(district_codes_by_muni[mcode])),
                "label_lon": label_lon,
                "label_lat": label_lat,
            },
            "geometry": mapping(merged),
        }
        munis_by_county[lcode].append(feat)
        all_muni_features.append(feat)

    for lcode, feats in munis_by_county.items():
        dump(municipalities_dir / f"{lcode}.geojson", {
            "type": "FeatureCollection",
            "features": sorted(feats, key=lambda f: f["properties"]["name"]),
        })

    dump(out_dir / "municipalities_all.geojson", {
        "type": "FeatureCollection",
        "features": sorted(all_muni_features, key=lambda f: f["properties"]["name"]),
    })

    county_features = []
    for lcode, geoms in county_geoms.items():
        merged = unary_union(geoms)
        if not merged.is_valid:
            merged = merged.buffer(0)
        merged = merged.simplify(0.0015, preserve_topology=True)
        muni_codes = sorted([m for m in muni_geoms if m.startswith(lcode)])
        district_count = sum(len(set(district_codes_by_muni[m])) for m in muni_codes)
        label_lon, label_lat = label_point(merged)
        county_features.append({
            "type": "Feature",
            "properties": {
                "code": lcode,
                "name": county_names.get(lcode, COUNTY_NAMES.get(lcode, f"Län {lcode}")),
                "municipality_count": len(muni_codes),
                "district_count": district_count,
                "label_lon": label_lon,
                "label_lat": label_lat,
            },
            "geometry": mapping(merged),
        })

    dump(out_dir / "counties.geojson", {
        "type": "FeatureCollection",
        "features": sorted(county_features, key=lambda f: f["properties"]["name"]),
    })

    if temp_dir is not None:
        build_water(out_dir, temp_dir)
    elif not (out_dir / "water.geojson").exists():
        (out_dir / "water.geojson").write_text('{"type":"FeatureCollection","features":[]}', encoding="utf-8")

    meta = {
        "district_total": found,
        "municipality_total": len(muni_geoms),
        "county_total": len(county_geoms),
        "municipality_names": muni_names,
        "county_names": county_names,
        "district_codes_by_municipality": {k: sorted(set(v)) for k, v in district_codes_by_muni.items()},
        "built_at": time.time(),
        "source": "Valmyndigheten",
        "source_url": GIS_ZIP_URL,
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    print(f"[geo] Built {found} districts, {len(muni_geoms)} municipalities, {len(county_geoms)} counties")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--zip", dest="zip_path")
    args = ap.parse_args()
    out = Path(args.out)
    if args.zip_path:
        zp = Path(args.zip_path)
        with tempfile.TemporaryDirectory() as td:
            build(out, zp, Path(td))
        return
    with tempfile.TemporaryDirectory() as td:
        temp_dir = Path(td)
        zp = temp_dir / "valdistrikt-riket-2026.zip"
        download(GIS_ZIP_URL, zp)
        build(out, zp, temp_dir)


if __name__ == "__main__":
    main()
