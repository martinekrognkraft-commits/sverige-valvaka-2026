from __future__ import annotations

import io
import json
import mimetypes
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.request
import zipfile
from collections import defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qs, urlparse

APP_VERSION = "3.3-apk"
POLL_SECONDS = 60
PORT = 8765
RESULT_INDEX_URL = "https://resultat.val.se/resultatfiler/val2026/index.md5"
RESULT_RELATIVE_PATH = "./p/rd/Val_2026_preliminar_00_RD.zip"
RESULT_BASE_URL = "https://resultat.val.se/resultatfiler/val2026/"

PARTY_COLORS = {
    "S": "#e11d48", "M": "#38bdf8", "SD": "#facc15", "C": "#22c55e",
    "V": "#dc2626", "MP": "#84cc16", "KD": "#1d4ed8", "L": "#0284c7",
    "ÖVR": "#94a3b8",
}

state_lock = threading.RLock()
update_guard = threading.Lock()
state: dict[str, Any] = {
    "results": {}, "checksum": None, "last_checked": None, "last_updated": None,
    "error": None, "next_poll": None, "demo": False,
    "updating": False, "stage": "idle", "stage_since": None,
    "last_duration": None, "last_refresh_request": None,
}
geo_meta: dict[str, Any] = {}
BASE = Path(".")
DATA = BASE / "data"
GEO = DATA / "geo"
DISTRICTS_DIR = GEO / "districts"
MUNICIPALITIES_DIR = GEO / "municipalities"
COUNTIES_FILE = GEO / "counties.geojson"
ALL_MUNICIPALITIES_FILE = GEO / "municipalities_all.geojson"
WATER_FILE = GEO / "water.geojson"
META_FILE = GEO / "meta.json"
RESULT_ZIP = DATA / "Val_2026_preliminar_00_RD.zip"
RESULT_JSON = DATA / "result_current.json"
STATIC_DIR = BASE / "static"
_server_started = False

def norm(s: Any) -> str:
    text = str(s or "").strip().lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]", "", text)

def req_bytes(url: str, timeout: int = 30) -> bytes:
    r = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Sverige-Valvaka-2026/1.0 (+lokal valvaka; source Valmyndigheten)",
            "Accept": "*/*",
        },
    )
    with urllib.request.urlopen(r, timeout=timeout) as resp:
        return resp.read()

def party_code(value: Any) -> str | None:
    s = str(value or "").strip()
    upper = s.upper().replace("OVR", "ÖVR")
    # Valmyndighetens olika presentationer/format kan använda flera kortformer
    # för samlingsposten övriga anmälda partier.
    aliases = {
        "S": "S", "M": "M", "SD": "SD", "C": "C", "V": "V",
        "MP": "MP", "KD": "KD", "L": "L",
        "ÖVR": "ÖVR", "Ö": "ÖVR", "ÖAP": "ÖVR", "ÖP": "ÖVR",
    }
    if upper in aliases:
        return aliases[upper]
    n = norm(s)
    checks = [
        ("sverigedemokrat", "SD"), ("socialdemokrat", "S"), ("moderater", "M"),
        ("centerpart", "C"), ("vansterpart", "V"), ("miljopart", "MP"),
        ("kristdemokrat", "KD"), ("liberal", "L"),
        ("ovriga anmalda partier", "ÖVR"), ("ovrigaanmaldapartier", "ÖVR"),
        ("ovriga partier", "ÖVR"), ("ovrigapartier", "ÖVR")
    ]
    for needle, code in checks:
        if norm(needle) in n:
            return code
    return None

def as_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        t = value.replace("\u00a0", " ").replace(" ", "").replace("%", "").replace(",", ".")
        if re.fullmatch(r"-?\d+(?:\.\d+)?", t):
            try:
                return float(t)
            except ValueError:
                pass
    return None

def direct_district_code(d: dict[str, Any]) -> str | None:
    # Prioritera nycklar som explicit beskriver valdistrikt.
    for k, v in d.items():
        nk = norm(k)
        if "valdistr" in nk and "kod" in nk:
            m = re.search(r"(?<!\d)(\d{8})(?!\d)", str(v))
            if m:
                return m.group(1)
    # Fallback på direkta 8-siffriga kodfält.
    for k, v in d.items():
        nk = norm(k)
        if nk in {"kod", "id", "omradeskod", "valomradeskod"}:
            m = re.fullmatch(r"\s*(\d{8})\s*", str(v))
            if m:
                return m.group(1)
    return None

def parse_party_rows(node: Any, district_code: str, depth: int = 0, inherited_party: str | None = None) -> dict[str, int]:
    """Plocka ut röster per parti ur ett valdistriktsobjekt.

    Valmyndighetens JSON kan representera ett parti antingen som en vanlig rad
    (partiförkortning + röstetal), som en enkel mapping {"S": 123}, eller som
    ett nästlat objekt där själva partinamnet ligger i föräldern och röstetalet
    i ett barnfält. Den sista varianten är särskilt viktig för ÖVR.
    """
    if depth > 9:
        return {}
    votes: dict[str, int] = {}

    if isinstance(node, dict):
        other_code = direct_district_code(node)
        if other_code and other_code != district_code and depth > 0:
            return {}

        # Parti kan anges explicit i objektet eller ärvas från nyckeln ovanför,
        # t.ex. {"Övriga anmälda partier": {"antalRöster": 17}}.
        pval = inherited_party
        for k, v in node.items():
            nk = norm(k)
            if nk in {
                "partiforkortning", "parti", "partibeteckning", "partinamn",
                "forkortning", "partikodnamn", "partibeteckningnamn"
            }:
                pc = party_code(v)
                if pc:
                    pval = pc
                    break

        if pval:
            candidates: list[tuple[int, int]] = []
            for k, v in node.items():
                num = as_number(v)
                if num is None or num < 0:
                    continue
                nk = norm(k)
                if any(x in nk for x in ("procent", "andel", "forandring", "jamforelse", "foregaende")):
                    continue
                # Röstfält prioriteras. För ett parti som ärvts från föräldern
                # accepteras även generiska antal-/summafälten.
                if "rost" in nk or "vote" in nk:
                    if not any(x in nk for x in ("giltig", "ogiltig", "total", "samtliga")):
                        candidates.append((100, int(round(num))))
                    elif pval == "ÖVR" and "ogiltig" not in nk:
                        candidates.append((85, int(round(num))))
                elif inherited_party and nk in {"antal", "summa", "total", "varde", "value"}:
                    candidates.append((70, int(round(num))))
            if candidates:
                best_score = max(score for score, _ in candidates)
                best = max(n for score, n in candidates if score == best_score)
                votes[pval] = max(votes.get(pval, 0), best)

        # Format som {"S": 123, "M": 98, ...} samt nästlade partiobjekt.
        for k, v in node.items():
            pc = party_code(k)
            num = as_number(v)
            if pc and num is not None and num >= 0:
                votes[pc] = max(votes.get(pc, 0), int(round(num)))
                continue
            if pc and isinstance(v, (dict, list)):
                child = parse_party_rows(v, district_code, depth + 1, inherited_party=pc)
            else:
                child = parse_party_rows(v, district_code, depth + 1, inherited_party=pval)
            for p, n in child.items():
                votes[p] = max(votes.get(p, 0), n)

    elif isinstance(node, list):
        for x in node:
            child = parse_party_rows(x, district_code, depth + 1, inherited_party=inherited_party)
            for p, n in child.items():
                votes[p] = max(votes.get(p, 0), n)
    return votes

def _scalar_vote_candidates(node: Any, district_code: str) -> dict[str, list[tuple[int, int]]]:
    """Hitta totalsiffror i ett valdistriktsobjekt.

    Klassificeringen tittar både på den aktuella nyckeln och hela sökvägen.
    Det gör att format som {"giltigaRöster": {"antal": 812}} och
    {"övrigaAnmäldaPartier": {"röster": 13}} fungerar, inte bara plana fält.
    """
    out: dict[str, list[tuple[int, int]]] = defaultdict(list)

    def walk(x: Any, path: tuple[str, ...] = (), depth: int = 0):
        if depth > 10:
            return
        if isinstance(x, dict):
            other_code = direct_district_code(x)
            if other_code and other_code != district_code and depth > 0:
                return
            for k, v in x.items():
                nk = norm(k)
                full_parts = tuple(norm(p) for p in path + (str(k),))
                full = " ".join(full_parts)
                compact = "".join(full_parts)
                historical = any(t in compact for t in (
                    "foregaende", "tidigare", "jamforelse", "forandring", "2022"
                ))
                num = as_number(v)
                if num is not None and num >= 0 and not historical:
                    iv = int(round(num))
                    percentish = any(t in compact for t in ("procent", "andel"))

                    if not percentish:
                        # Giltiga röster. Matcha även när 'giltigaRöster' ligger
                        # i en föräldernyckel och det numeriska barnet heter 'antal'.
                        if "giltig" in compact and "rost" in compact and "ogiltig" not in compact:
                            score = 100
                            if any(t in compact for t in ("antal", "total", "summa")):
                                score += 15
                            out["valid"].append((score, iv))

                        # Samtliga räknade/avgivna röster inklusive ogiltiga.
                        counted_context = any(t in compact for t in (
                            "raknadrost", "raknaderost", "avgivnarost", "avgivenrost",
                            "mottagnarost", "summaroster", "rostsumma", "totalaroster",
                            "totalroster", "rostertotalt"
                        ))
                        if counted_context:
                            score = 60 + (10 if any(t in compact for t in ("antal", "total", "summa")) else 0)
                            out["counted"].append((score, iv))

                        # Ogiltiga röster. Totalfält får högre poäng än delposter.
                        if "ogiltig" in compact and ("rost" in compact or "antal" in compact or "total" in compact):
                            score = 55
                            if any(t in compact for t in ("total", "totalt", "summa", "antalogiltig")):
                                score += 15
                            out["invalid"].append((score, iv))

                        # Fallback om Valmyndigheten bara skickar de tre ogiltig-kategorierna.
                        if "blank" in compact:
                            out["blank"].append((50, iv))
                        if ("ejanmal" in compact or "inteanmal" in compact) and "part" in compact:
                            out["unregistered"].append((50, iv))
                        if "ovrig" in compact and "ogiltig" in compact:
                            out["invalid_other"].append((50, iv))

                        # Övriga anmälda partier kan ligga som ett separat objekt.
                        other_context = (
                            ("ovrig" in compact and ("part" in compact or "anmal" in compact))
                            or "ovr" in full_parts
                        )
                        if other_context and "ogiltig" not in compact:
                            score = 90
                            if "rost" in compact or any(t in compact for t in ("antal", "summa", "total")):
                                score += 10
                            out["other"].append((score, iv))

                walk(v, path + (str(k),), depth + 1)
        elif isinstance(x, list):
            for i, y in enumerate(x):
                walk(y, path + (str(i),), depth + 1)

    walk(node)
    return out

def _best_candidate(values: list[tuple[int, int]], minimum: int = 0) -> int | None:
    vals = [(score, n) for score, n in values if n >= minimum]
    if not vals:
        return None
    best_score = max(score for score, _ in vals)
    # Vid samma kvalitet föredras den största totalsumman, vilket brukar vara
    # den aktuella totalsiffran snarare än en delpost.
    return max(n for score, n in vals if score == best_score)

def ensure_other_votes(node: Any, district_code: str, votes: dict[str, int]) -> dict[str, int]:
    """Säkerställ att ÖVR ingår i preliminära röstandelar.

    Prioritet:
      1) ÖVR som vanlig/nästlad partirad.
      2) Ett separat fält för övriga anmälda partier.
      3) Giltiga röster minus de åtta rapportpartierna.
      4) Totalt räknade röster minus ogiltiga minus rapportpartierna.
    """
    fixed = dict(votes)
    cands = _scalar_vote_candidates(node, district_code)

    # Behåll explicit ÖVR från partiparsningen om den finns, även när den är 0.
    if "ÖVR" in fixed:
        return fixed

    explicit_other = _best_candidate(cands.get("other", []), minimum=0)
    if explicit_other is not None:
        fixed["ÖVR"] = explicit_other
        return fixed

    known = sum(int(n) for p, n in fixed.items() if p != "ÖVR")
    valid = _best_candidate(cands.get("valid", []), minimum=known)

    if valid is None:
        counted = _best_candidate(cands.get("counted", []), minimum=known)
        # Använd bara ett explicit totalfält för ogiltiga här. Enskilda
        # kategorier (blanka/ej anmälda/övriga ogiltiga) summeras separat.
        strong_invalid = [(score, n) for score, n in cands.get("invalid", []) if score >= 65]
        invalid = _best_candidate(strong_invalid, minimum=0)
        if invalid is None:
            pieces = []
            for key in ("blank", "unregistered", "invalid_other"):
                val = _best_candidate(cands.get(key, []), minimum=0)
                if val is not None:
                    pieces.append(val)
            if pieces:
                invalid = sum(pieces)
        if counted is not None and invalid is not None and counted >= invalid + known:
            valid = counted - invalid

    if valid is not None and valid >= known:
        fixed["ÖVR"] = max(0, valid - known)
    return fixed

def detect_complete(node: Any, votes: dict[str, int]) -> bool:
    positive_signal = False
    negative_signal = False

    def walk(x: Any, depth: int = 0):
        nonlocal positive_signal, negative_signal
        if depth > 6:
            return
        if isinstance(x, dict):
            for k, v in x.items():
                nk = norm(k)
                if any(t in nk for t in ("status", "fardig", "klar", "rapporter", "raknad")):
                    if isinstance(v, bool):
                        positive_signal |= v
                        negative_signal |= not v
                    else:
                        sv = norm(v)
                        if any(t in sv for t in ("fardig", "klar", "rapporterad", "slutford", "complete")):
                            positive_signal = True
                        if any(t in sv for t in ("ejrapporterad", "inteklar", "pagar", "notreported")):
                            negative_signal = True
                walk(v, depth + 1)
        elif isinstance(x, list):
            for y in x:
                walk(y, depth + 1)
    walk(node)
    if positive_signal:
        return True
    if negative_signal and not votes:
        return False
    # Valmyndigheten publicerar valdistriktsresultatet när distriktet är färdigräknat.
    return sum(votes.values()) > 0

def extract_results(doc: Any) -> dict[str, dict[str, Any]]:
    found: dict[str, dict[str, Any]] = {}

    def walk(x: Any):
        if isinstance(x, dict):
            code = direct_district_code(x)
            if code:
                votes = parse_party_rows(x, code)
                votes = ensure_other_votes(x, code, votes)
                complete = detect_complete(x, votes)
                if votes or complete:
                    leader = max(votes, key=votes.get) if votes else None
                    found[code] = {
                        "complete": bool(complete),
                        "leader": leader,
                        "votes": votes,
                        "total_votes": int(sum(votes.values())),
                    }
                return
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for y in x:
                walk(y)

    walk(doc)
    return found

def project_national_mandates(votes: dict[str, int], seats: int = 349) -> dict[str, int]:
    """En enkel nationell mandatprognos med jämkad uddatalsmetod.

    Den används bara tills Valmyndighetens preliminära mandatfördelning kan
    tolkas ur mandatfilen. Den tar hänsyn till 4 %-spärren nationellt men inte
    12 %-regeln i enskilda valkretsar, och märks därför tydligt som prognos i UI.
    """
    cleaned = {p: max(0, int(n)) for p, n in votes.items() if party_code(p)}
    total_votes = sum(cleaned.values())
    if total_votes <= 0:
        return {}
    # ÖVR är en samlingskategori för flera mindre partier och får därför inte
    # behandlas som ett enda parti i mandatprognosen. Däremot ska dess röster
    # ligga kvar i totalen/nämnaren när 4 %-spärren bedöms.
    eligible = {p: n for p, n in cleaned.items() if p != "ÖVR" and n / total_votes >= 0.04}
    if not eligible:
        return {}
    allocated = {p: 0 for p in eligible}
    for _ in range(seats):
        def quotient(item):
            p, n = item
            m = allocated[p]
            divisor = 1.2 if m == 0 else (2 * m + 1)
            return n / divisor
        winner = max(eligible.items(), key=quotient)[0]
        allocated[winner] += 1
    return allocated

def extract_mandates(doc: Any) -> dict[str, int]:
    """Försöker läsa total mandatfördelning per parti ur Valmyndighetens mandat-JSON.

    Schemat innehåller flera mandatfält på olika nivåer. Vi prioriterar därför
    uttryckliga total-/antal-mandatfält och ignorerar jämförelser med föregående val.
    Om formatet ändras faller gränssnittet tillbaka till en tydligt märkt prognos.
    """
    candidates: dict[str, list[tuple[int, int]]] = defaultdict(list)

    def direct_party(d: dict[str, Any]) -> str | None:
        for k, v in d.items():
            nk = norm(k)
            if nk in {"partiforkortning", "parti", "partibeteckning", "partinamn", "forkortning"}:
                pc = party_code(v)
                if pc:
                    return pc
        return None

    def walk(x: Any, inherited_party: str | None = None, depth: int = 0):
        if depth > 12:
            return
        if isinstance(x, dict):
            p = direct_party(x) or inherited_party
            if p:
                for k, v in x.items():
                    nk = norm(k)
                    if "mandat" not in nk:
                        continue
                    if any(t in nk for t in ("foregaende", "tidigare", "jamforelse", "forandring", "ersatt", "person")):
                        continue
                    num = as_number(v)
                    if num is None or num < 0 or num > 349 or abs(num-round(num)) > 1e-9:
                        continue
                    score = 0
                    if nk in {"mandat", "antalmandat", "mandatantal"}:
                        score += 8
                    if any(t in nk for t in ("total", "totalt", "summa")):
                        score += 10
                    if any(t in nk for t in ("fast", "utjamn", "valkrets")):
                        score -= 5
                    candidates[p].append((score, int(round(num))))
            for v in x.values():
                walk(v, p, depth + 1)
        elif isinstance(x, list):
            for y in x:
                walk(y, inherited_party, depth + 1)

    walk(doc)
    out: dict[str, int] = {}
    for p, vals in candidates.items():
        if not vals:
            continue
        best_score = max(score for score, _ in vals)
        if best_score < 0:
            continue
        best_values = [n for score, n in vals if score == best_score]
        if best_values:
            out[p] = max(best_values)

    total = sum(out.values())
    # Vi visar bara mandatdata som "Valmyndigheten" när parsningen ger hela riksdagens 349 mandat.
    # Annars används den tydligt märkta mandatprognosen tills mandatfilen är komplett/tolkbar.
    if total != 349 or any(v > 200 for v in out.values()):
        return {}
    return out

def aggregate_results(district_results: dict[str, dict[str, Any]], mandates: dict[str, int] | None = None) -> dict[str, Any]:
    district_codes_by_muni = geo_meta.get("district_codes_by_municipality", {})
    muni_out: dict[str, Any] = {}
    county_votes: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    county_done: dict[str, int] = defaultdict(int)
    county_total: dict[str, int] = defaultdict(int)
    national_votes: dict[str, int] = defaultdict(int)
    reported_total = 0

    for mcode, codes in district_codes_by_muni.items():
        votes = defaultdict(int)
        done = 0
        for code in codes:
            r = district_results.get(code)
            if r and r.get("complete"):
                done += 1
                reported_total += 1
                for p, n in r.get("votes", {}).items():
                    votes[p] += int(n)
                    county_votes[mcode[:2]][p] += int(n)
                    national_votes[p] += int(n)
        total = len(codes)
        leader = max(votes, key=votes.get) if votes else None
        muni_out[mcode] = {
            "complete": total > 0 and done == total,
            "leader": leader,
            "reported": done,
            "total": total,
            "progress": done / total if total else 0,
            "votes": dict(votes),
        }
        county_done[mcode[:2]] += done
        county_total[mcode[:2]] += total

    county_out = {}
    for lcode, total in county_total.items():
        votes = dict(county_votes[lcode])
        leader = max(votes, key=votes.get) if votes else None
        county_out[lcode] = {
            "complete": total > 0 and county_done[lcode] == total,
            "leader": leader,
            "reported": county_done[lcode],
            "total": total,
            "progress": county_done[lcode] / total if total else 0,
            "votes": votes,
        }

    dist_out = {}
    for code, r in district_results.items():
        if code[:4] in district_codes_by_muni:
            dist_out[code] = {
                "complete": bool(r.get("complete")),
                "leader": r.get("leader"),
                "reported": 1 if r.get("complete") else 0,
                "total": 1,
                "progress": 1 if r.get("complete") else 0,
                "votes": r.get("votes", {}),
                "total_votes": r.get("total_votes", 0),
            }

    nat_total_votes = sum(national_votes.values())
    national_vote_dict = dict(national_votes)
    complete_rows = [r for r in district_results.values() if r.get("complete")]
    ovr_districts = sum(1 for r in complete_rows if "ÖVR" in (r.get("votes") or {}))
    national = {
        "reported": reported_total,
        "total": int(geo_meta.get("district_total", 0)),
        "progress": reported_total / max(1, int(geo_meta.get("district_total", 0))),
        "votes": national_vote_dict,
        "valid_votes": nat_total_votes,
        "other_votes": int(national_vote_dict.get("ÖVR", 0)),
        "ovr_districts": ovr_districts,
        "ovr_coverage": ovr_districts / max(1, len(complete_rows)),
        "shares": {p: n / nat_total_votes * 100 for p, n in national_votes.items()} if nat_total_votes else {},
        "mandates": mandates or {},
        "mandates_source": "Valmyndigheten" if mandates else None,
        "mandate_projection": project_national_mandates(national_vote_dict),
    }
    return {"districts": dist_out, "municipalities": muni_out, "counties": county_out, "national": national}

def load_result_zip(blob: bytes) -> tuple[dict[str, dict[str, Any]], dict[str, int]]:
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        vote_names = [n for n in zf.namelist() if n.endswith(".json") and "rostfordelning" in norm(n)]
        mandate_names = [n for n in zf.namelist() if n.endswith(".json") and "mandatfordelning" in norm(n)]
        if not vote_names:
            raise RuntimeError("Hittade ingen röstfördelnings-JSON i resultat-ZIP.")
        vote_doc = json.loads(zf.read(vote_names[0]).decode("utf-8-sig"))
        parsed = extract_results(vote_doc)
        if len(parsed) < 10:
            (DATA / "parser_debug.json").write_text(json.dumps(vote_doc, ensure_ascii=False)[:5_000_000], encoding="utf-8")
            raise RuntimeError(f"Resultatparsern hittade bara {len(parsed)} valdistrikt. Se data/parser_debug.json.")
        mandates: dict[str, int] = {}
        if mandate_names:
            try:
                mandate_doc = json.loads(zf.read(mandate_names[0]).decode("utf-8-sig"))
                mandates = extract_mandates(mandate_doc)
            except Exception as e:
                print("[live] Kunde inte tolka mandatfilen, använder prognos:", e)
        return parsed, mandates

def configure_runtime(runtime_dir: str):
    global BASE, DATA, GEO, DISTRICTS_DIR, MUNICIPALITIES_DIR, COUNTIES_FILE
    global ALL_MUNICIPALITIES_FILE, WATER_FILE, META_FILE, RESULT_ZIP, RESULT_JSON, STATIC_DIR, geo_meta
    BASE = Path(runtime_dir)
    DATA = BASE / "data"
    GEO = DATA / "geo"
    DISTRICTS_DIR = GEO / "districts"
    MUNICIPALITIES_DIR = GEO / "municipalities"
    COUNTIES_FILE = GEO / "counties.geojson"
    ALL_MUNICIPALITIES_FILE = GEO / "municipalities_all.geojson"
    WATER_FILE = GEO / "water.geojson"
    META_FILE = GEO / "meta.json"
    RESULT_ZIP = DATA / "Val_2026_preliminar_00_RD.zip"
    RESULT_JSON = DATA / "result_current.json"
    STATIC_DIR = BASE / "static"
    DATA.mkdir(parents=True, exist_ok=True)
    if not META_FILE.exists():
        raise RuntimeError("Kartdata saknas i APK:n (meta.json hittades inte).")
    geo_meta = json.loads(META_FILE.read_text(encoding="utf-8"))
    if RESULT_JSON.exists():
        try:
            cached = json.loads(RESULT_JSON.read_text(encoding="utf-8"))
            if isinstance(cached, dict) and "national" in cached:
                state["results"] = cached
        except Exception:
            pass


def load_geo(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _set_stage(stage: str):
    with state_lock:
        state["stage"] = stage
        state["stage_since"] = time.time()


def update_once(force: bool = False):
    # Bara en hämtning/parser får köras åt gången. På v3.0 kunde första
    # uppdateringen, 60-sekunderspollningen och manuella refresh-tryck starta
    # flera tunga parsningar parallellt och hålla resultatet på 0/0 länge.
    if not update_guard.acquire(blocking=False):
        with state_lock:
            state["last_refresh_request"] = time.time()
        return False

    started = time.time()
    with state_lock:
        state["last_checked"] = started
        state["error"] = None
        state["updating"] = True
        state["stage"] = "index"
        state["stage_since"] = started
        state["next_poll"] = None
    try:
        idx = req_bytes(RESULT_INDEX_URL, timeout=20).decode("utf-8", errors="replace")
        checksum = None
        for line in idx.splitlines():
            # Acceptera både ./p/rd/... och p/rd/... om indexformatet varierar.
            normalized_line = line.replace("\\", "/")
            target = RESULT_RELATIVE_PATH.lstrip("./")
            if RESULT_RELATIVE_PATH in normalized_line or target in normalized_line:
                checksum = line.split()[0]
                break
        if not checksum:
            raise RuntimeError("Riksdagens preliminära ZIP hittades inte i index.md5.")

        with state_lock:
            unchanged = checksum == state.get("checksum") and bool(state.get("results"))
        if unchanged and not force:
            _set_stage("ready")
            return True

        _set_stage("download")
        url = RESULT_BASE_URL.rstrip("/") + "/" + RESULT_RELATIVE_PATH.lstrip("./")
        blob = req_bytes(url, timeout=60)
        RESULT_ZIP.write_bytes(blob)

        _set_stage("parse")
        district_results, mandates = load_result_zip(blob)

        _set_stage("aggregate")
        aggregated = aggregate_results(district_results, mandates=mandates)

        _set_stage("save")
        RESULT_JSON.write_text(json.dumps(aggregated, ensure_ascii=False), encoding="utf-8")
        with state_lock:
            state["results"] = aggregated
            state["checksum"] = checksum
            state["last_updated"] = time.time()
            state["error"] = None
            state["stage"] = "ready"
            state["stage_since"] = time.time()
        return True
    except urllib.error.HTTPError as e:
        msg = ("Valmyndigheten rate-limit:ar just nu (HTTP 429). Försöker igen senare."
               if e.code == 429 else f"Valmyndigheten svarade HTTP {e.code}.")
        with state_lock:
            state["error"] = msg
            state["stage"] = "error"
            state["stage_since"] = time.time()
        return False
    except Exception as e:
        with state_lock:
            state["error"] = str(e)
            state["stage"] = "error"
            state["stage_since"] = time.time()
        return False
    finally:
        finished = time.time()
        with state_lock:
            state["updating"] = False
            state["last_duration"] = finished - started
        update_guard.release()


def updater_loop():
    # Kör direkt vid start, men vänta alltid tills körningen är helt färdig innan
    # nästa 60-sekundersintervall börjar. Det förhindrar kö av parsertrådar.
    delay = 0
    while True:
        if delay:
            with state_lock:
                state["next_poll"] = time.time() + delay
            time.sleep(delay)
        update_once()
        with state_lock:
            delay = 300 if state.get("error") and "429" in str(state["error"]) else POLL_SECONDS


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "SverigeValvaka/3.3"

    def log_message(self, fmt, *args):
        return

    def _send_bytes(self, data: bytes, content_type: str, status: int = 200, cache: str = "no-store"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, obj: Any, status: int = 200):
        self._send_bytes(_json_bytes(obj), "application/json; charset=utf-8", status=status)

    def _send_file(self, root: Path, relative: str):
        root = root.resolve()
        path = (root / relative).resolve()
        if root != path and root not in path.parents:
            self._send_json({"error": "Ogiltig sökväg"}, 403)
            return
        if not path.is_file():
            self._send_json({"error": "Hittades inte"}, 404)
            return
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        cache = "public, max-age=31536000" if "/static/" in self.path else "no-store"
        self._send_bytes(path.read_bytes(), ctype, cache=cache)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        q = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            self._send_file(STATIC_DIR, "index.html")
            return
        if path.startswith("/static/"):
            self._send_file(STATIC_DIR / "static", path[len("/static/"):])
            return
        if path == "/api/bootstrap":
            with state_lock:
                st = dict(state)
            self._send_json({
                "app_version": APP_VERSION,
                "party_colors": PARTY_COLORS,
                "poll_seconds": POLL_SECONDS,
                "geo": {
                    "district_total": geo_meta.get("district_total", 0),
                    "municipality_total": geo_meta.get("municipality_total", 0),
                    "county_total": geo_meta.get("county_total", 0),
                },
                "status": {k: st.get(k) for k in ("last_checked", "last_updated", "error", "next_poll", "demo", "updating", "stage", "stage_since", "last_duration")},
            })
            return
        if path == "/api/results":
            with state_lock:
                payload = state.get("results") or {"districts": {}, "municipalities": {}, "counties": {}, "national": {}}
                status = {k: state.get(k) for k in ("checksum", "last_checked", "last_updated", "error", "next_poll", "demo", "updating", "stage", "stage_since", "last_duration")}
            self._send_json({"results": payload, "status": status})
            return
        if path == "/api/geo/counties":
            self._send_json(load_geo(COUNTIES_FILE))
            return
        if path == "/api/geo/water":
            if WATER_FILE.exists():
                self._send_json(load_geo(WATER_FILE))
            else:
                self._send_json({"type":"FeatureCollection","features":[]})
            return
        if path == "/api/geo/municipalities/all":
            if ALL_MUNICIPALITIES_FILE.exists():
                self._send_json(load_geo(ALL_MUNICIPALITIES_FILE))
            else:
                features = []
                for p in sorted(MUNICIPALITIES_DIR.glob("*.geojson")):
                    features.extend(load_geo(p).get("features", []))
                self._send_json({"type": "FeatureCollection", "features": features})
            return
        if path == "/api/geo/municipalities":
            code = re.sub(r"\D", "", (q.get("county") or [""])[0])[:2]
            f = MUNICIPALITIES_DIR / f"{code}.geojson"
            if not f.exists():
                self._send_json({"type": "FeatureCollection", "features": []}, 404)
            else:
                self._send_json(load_geo(f))
            return
        if path == "/api/geo/districts":
            code = re.sub(r"\D", "", (q.get("municipality") or [""])[0])[:4]
            f = DISTRICTS_DIR / f"{code}.geojson"
            if not f.exists():
                self._send_json({"type": "FeatureCollection", "features": []}, 404)
            else:
                self._send_json(load_geo(f))
            return
        self._send_json({"error": "Hittades inte"}, 404)

    def do_POST(self):
        if urlparse(self.path).path == "/api/refresh":
            with state_lock:
                busy = bool(state.get("updating"))
                state["last_refresh_request"] = time.time()
            if not busy:
                threading.Thread(target=update_once, kwargs={"force": True}, daemon=True, name="valvaka-manual-update").start()
            self._send_json({"ok": True, "started": not busy, "busy": busy})
            return
        self._send_json({"error": "Hittades inte"}, 404)


def start_server(runtime_dir: str):
    global _server_started
    if _server_started:
        return True
    configure_runtime(runtime_dir)
    _server_started = True

    threading.Thread(target=updater_loop, daemon=True, name="valvaka-updater").start()

    def serve():
        httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
        httpd.daemon_threads = True
        httpd.serve_forever(poll_interval=0.5)

    threading.Thread(target=serve, daemon=True, name="valvaka-http").start()
    return True
