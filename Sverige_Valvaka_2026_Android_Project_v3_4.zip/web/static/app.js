const FRONTEND_VERSION = '3.4-apk';

const state = {
  level: 'counties',
  county: null,
  municipality: null,
  geo: null,
  overviewGeo: null,
  results: {counties:{}, municipalities:{}, districts:{}, national:{}},
  colors: {},
  popup: null,
  modalFeature: null,
  selectedCode: null,
  parentFeature: null,
  lastStatus: {},
  suppressDistrictClickUntil: 0,
};

const $ = (id) => document.getElementById(id);
const PARTY_ORDER = ['V','S','MP','C','L','KD','M','SD','ÖVR'];
const LEFT_BLOCK = new Set(['V','S','MP','C']);
const RIGHT_BLOCK = new Set(['L','KD','M','SD']);

const map = new maplibregl.Map({
  container: 'map',
  center: [16.2, 62.1],
  zoom: 3.55,
  minZoom: 2.6,
  maxZoom: 13,
  attributionControl: true,
  // v3.4 uses a real vector basemap instead of the old OSM raster overlay.
  // Fiord is a dark OpenFreeMap/OpenMapTiles style based on OpenStreetMap data.
  style: 'https://tiles.openfreemap.org/styles/fiord'
});

map.addControl(new maplibregl.NavigationControl({showCompass:false}), 'bottom-right');

function partyColor(p) { return state.colors[p] || '#64748b'; }
function fmtPct(value) { return Number(value || 0).toFixed(1).replace('.', ','); }
function fmtInt(value) { return Number(value || 0).toLocaleString('sv-SE'); }
function esc(value) {
  return String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

async function fetchJson(url, options={}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error(`${url} svarade HTTP ${response.status}`);
  }
  return response.json();
}

function showFrontendError(message) {
  $('errorCard').classList.remove('hidden');
  $('errorText').textContent = message;
}

function colorExpression() {
  const expr = ['match', ['get','leader']];
  for (const [p,c] of Object.entries(state.colors)) expr.push(p,c);
  expr.push('#64748b');
  return ['case', ['==',['get','colorReady'], true], expr, '#2d3a48'];
}

function resultFor(kind, code) {
  const bucket = kind === 'county' ? state.results.counties : kind === 'municipality' ? state.results.municipalities : state.results.districts;
  return (bucket || {})[code] || {};
}

function decorateGeo(geo, kind) {
  return {
    type:'FeatureCollection',
    features:(geo?.features || []).map(f => {
      const code = String(f.properties.code || '');
      const r = resultFor(kind, code);
      const reported = Number(r.reported || 0);
      // Kommuner färgas så fort minst ett valdistrikt är klart. Valdistrikt kräver att distriktet är klart.
      const colorReady = kind === 'municipality' ? reported > 0 : kind === 'district' ? !!r.complete : !!r.complete;
      return {
        ...f,
        properties:{
          ...f.properties,
          complete:!!r.complete,
          colorReady,
          leader:r.leader || '',
          progress:Number(r.progress || 0),
          reported,
          total:Number(r.total || (kind === 'district' ? 1 : 0)),
        }
      };
    })
  };
}


function featureLabelPoint(feature) {
  const lon = Number(feature?.properties?.label_lon);
  const lat = Number(feature?.properties?.label_lat);
  if (Number.isFinite(lon) && Number.isFinite(lat)) return [lon, lat];
  const b = bboxOfFeature(feature);
  return [(b[0][0]+b[1][0])/2, (b[0][1]+b[1][1])/2];
}

function labelGeo(geo) {
  return {
    type:'FeatureCollection',
    features:(geo?.features || []).map(f=>({
      type:'Feature',
      properties:{...f.properties},
      geometry:{type:'Point',coordinates:featureLabelPoint(f)}
    }))
  };
}

function closeMapPanels() {
  $('searchPanel')?.classList.add('hidden');
  $('districtListPanel')?.classList.add('hidden');
}

function currentSearchFeatures() {
  if (state.level === 'counties') {
    return [...(state.geo?.features || []), ...(state.overviewGeo?.features || [])];
  }
  return state.geo?.features || [];
}

function renderSearchResults(query='') {
  const box = $('searchResults');
  if (!box) return;
  const q = query.trim().toLocaleLowerCase('sv-SE');
  const features = currentSearchFeatures()
    .filter(f => !q || String(f.properties?.name || '').toLocaleLowerCase('sv-SE').includes(q))
    .sort((a,b)=>String(a.properties?.name||'').localeCompare(String(b.properties?.name||''),'sv'))
    .slice(0, 40);
  box.innerHTML = features.length ? features.map(f=>{
    const code=String(f.properties.code||'');
    const type=code.length===2?'Län':code.length===4?'Kommun':'Valdistrikt';
    return `<button class="map-list-row search-result" data-code="${esc(code)}"><span><strong>${esc(f.properties.name)}</strong><small>${type}</small></span><span class="map-list-arrow">›</span></button>`;
  }).join('') : '<div class="map-list-empty">Inga träffar</div>';
  box.querySelectorAll('.search-result').forEach(btn=>btn.addEventListener('click', async()=>{
    const code=btn.dataset.code;
    const feature=currentSearchFeatures().find(f=>String(f.properties.code)===code);
    if (!feature) return;
    $('searchPanel').classList.add('hidden');
    if (code.length===2) await loadMunicipalities(feature);
    else if (code.length===4) {
      state.county={code:String(feature.properties.county_code||code.slice(0,2)),name:feature.properties.county_name||''};
      await loadDistricts(feature);
    } else focusDistrict(feature, true);
  }));
}

function renderDistrictList() {
  const btn=$('districtListBtn'), panel=$('districtListPanel'), list=$('districtList');
  if (!btn || !panel || !list) return;
  const isDistrict=state.level==='districts';
  const wasOpen=isDistrict && !panel.classList.contains('hidden');
  btn.classList.toggle('hidden', !isDistrict);
  if (!isDistrict) { panel.classList.add('hidden'); return; }
  const feats=[...(state.geo?.features||[])].sort((a,b)=>String(a.properties.name||'').localeCompare(String(b.properties.name||''),'sv'));
  $('districtListTitle').textContent=`Valdistrikt i ${state.municipality?.name||'kommunen'}`;
  btn.querySelector('span').textContent=`Valdistrikt ${feats.length}`;
  list.innerHTML=feats.map(f=>{
    const code=String(f.properties.code||'');
    const r=(state.results.districts||{})[code]||{};
    const status=r.complete?'Klart':'Ej klart';
    return `<button class="map-list-row district-row" data-code="${esc(code)}"><span><strong>${esc(f.properties.name)}</strong><small>${esc(status)}${r.leader?` · ${esc(r.leader)} leder`:''}</small></span><span class="party-mini" style="background:${r.leader?partyColor(r.leader):'#465665'}"></span></button>`;
  }).join('');
  list.querySelectorAll('.district-row').forEach(row=>row.addEventListener('click',()=>{
    const f=feats.find(x=>String(x.properties.code)===row.dataset.code);
    if (f) { panel.classList.add('hidden'); focusDistrict(f,true); }
  }));
  if (wasOpen) panel.classList.remove('hidden');
}

function basemapLabelLayerId() {
  // Insert election fills below the vector basemap's symbol layers so city,
  // road and water names stay crisp above the transparent party colours.
  const layers = map.getStyle()?.layers || [];
  const layer = layers.find(l => l.type === 'symbol' && !String(l.id || '').startsWith('area-'));
  return layer?.id || undefined;
}

function installLabels(geo, kind) {
  if (map.getLayer('area-labels-layer')) map.removeLayer('area-labels-layer');
  if (map.getSource('area-labels')) map.removeSource('area-labels');
  map.addSource('area-labels',{type:'geojson',data:labelGeo(geo)});

  const district=kind==='district';
  const municipality=kind==='municipality';
  const count=(geo?.features||[]).length;
  // Large rural municipalities often fit at zoom 4–5. In v3.2 the old minzoom
  // hid their labels completely. Small district sets may overlap a little on
  // purpose; finding the name is more useful than a perfectly clean map.
  const minzoom=district ? 3.8 : municipality ? 3.35 : 2.75;
  const allowOverlap=district && count <= 24;
  map.addLayer({
    id:'area-labels-layer',type:'symbol',source:'area-labels',minzoom,
    layout:{
      'text-field':['get','name'],
      'text-size':['interpolate',['linear'],['zoom'],3.5,district?10:11,6,district?11.5:12.5,9,district?13:14],
      'text-font':['Noto Sans Regular'],
      'text-max-width':district?10:12,
      'text-allow-overlap':allowOverlap,
      'text-ignore-placement':allowOverlap,
      'text-optional':true,
      'text-padding':district?1:3,
      'text-anchor':'center'
    },
    paint:{
      'text-color':'#ffffff',
      'text-halo-color':'rgba(3,10,18,.96)',
      'text-halo-width':2.0,
      'text-halo-blur':0.35
    }
  });
}

function installParentOutline(feature) {
  if (map.getLayer('parent-outline')) map.removeLayer('parent-outline');
  if (map.getSource('parent-area')) map.removeSource('parent-area');
  if (!feature) return;
  map.addSource('parent-area',{type:'geojson',data:{type:'FeatureCollection',features:[feature]}});
  map.addLayer({
    id:'parent-outline',type:'line',source:'parent-area',
    paint:{'line-color':'rgba(255,255,255,.96)','line-width':['interpolate',['linear'],['zoom'],4,1.8,8,3.2,11,4.0],'line-opacity':.95}
  });
}

function installSelectedOutline() {
  if (map.getLayer('selected-fill')) map.removeLayer('selected-fill');
  if (map.getLayer('selected-outline')) map.removeLayer('selected-outline');
  map.addLayer({
    id:'selected-fill',type:'fill',source:'areas',filter:['==',['get','code'],'__none__'],
    paint:{'fill-color':'#ffffff','fill-opacity':0.12}
  });
  map.addLayer({
    id:'selected-outline',type:'line',source:'areas',filter:['==',['get','code'],'__none__'],
    paint:{'line-color':'#ffffff','line-width':['interpolate',['linear'],['zoom'],5,2.6,10,5.0],'line-opacity':1}
  });
}

function selectAreaCode(code) {
  state.selectedCode=String(code||'');
  const filter=['==',['get','code'],state.selectedCode||'__none__'];
  if (map.getLayer('selected-fill')) map.setFilter('selected-fill',filter);
  if (map.getLayer('selected-outline')) map.setFilter('selected-outline',filter);
}

function focusDistrict(feature, openModal=false) {
  if (!feature) return;
  selectAreaCode(feature.properties.code);
  fitFeature(feature, 86, 11.2);
  renderSelection(feature);
  if (openModal) showDistrictModal(feature);
}

function removeAreaLayers() {
  const layers = ['county-lines','overview-muni-lines','overview-muni-fill','areas-lines','areas-fill','areas-hit','area-labels-layer','parent-outline','selected-fill','selected-outline'];
  for (const id of layers) if (map.getLayer(id)) map.removeLayer(id);
  for (const id of ['overview-munis','areas','area-labels','parent-area']) if (map.getSource(id)) map.removeSource(id);
  state.selectedCode=null;
}

function installNationalLayers(counties, municipalities) {
  state.geo = counties;
  state.overviewGeo = municipalities;
  state.parentFeature = null;
  removeAreaLayers();

  map.addSource('overview-munis', {type:'geojson', data:decorateGeo(municipalities, 'municipality')});
  map.addLayer({
    id:'overview-muni-fill', type:'fill', source:'overview-munis',
    paint:{
      'fill-color':colorExpression(),
      'fill-opacity':['case',['==',['get','colorReady'],true],0.52,0.13],
      'fill-color-transition':{duration:520,delay:0},
      'fill-opacity-transition':{duration:350,delay:0}
    }
  }, basemapLabelLayerId());
  map.addLayer({
    id:'overview-muni-lines', type:'line', source:'overview-munis',
    paint:{'line-color':'rgba(226,236,246,.38)','line-width':['interpolate',['linear'],['zoom'],3,0.35,5,0.75,7,1.0],'line-opacity':0.92}
  });
  map.addSource('areas', {type:'geojson', data:decorateGeo(counties, 'county')});
  map.addLayer({
    id:'county-lines', type:'line', source:'areas',
    paint:{'line-color':'rgba(255,255,255,.86)','line-width':['interpolate',['linear'],['zoom'],3,1.0,5,1.7,7,2.2],'line-opacity':0.95}
  });
  installLabels(counties,'county');
  map.addLayer({
    id:'areas-hit', type:'fill', source:'areas',
    paint:{'fill-color':'#ffffff','fill-opacity':0.001}
  });
}

function installAreaLayer(geo, kind, parentFeature=null) {
  state.geo = geo;
  state.overviewGeo = null;
  state.parentFeature = parentFeature;
  removeAreaLayers();
  map.addSource('areas', {type:'geojson', data:decorateGeo(geo, kind)});
  map.addLayer({
    id:'areas-fill', type:'fill', source:'areas',
    paint:{
      'fill-color':colorExpression(),
      'fill-opacity':['case',['==',['get','colorReady'],true],0.58,0.16],
      'fill-outline-color':'rgba(255,255,255,.16)',
      'fill-color-transition':{duration:500,delay:0},
      'fill-opacity-transition':{duration:350,delay:0}
    }
  }, basemapLabelLayerId());
  map.addLayer({
    id:'areas-lines', type:'line', source:'areas',
    paint:{'line-color':'rgba(230,240,255,.70)','line-width':['interpolate',['linear'],['zoom'],3,0.65,7,1.25,11,1.8],'line-opacity':0.94}
  });
  installParentOutline(parentFeature);
  installLabels(geo,kind);
  installSelectedOutline();
  map.addLayer({
    id:'areas-hit', type:'fill', source:'areas',
    paint:{'fill-color':'#ffffff','fill-opacity':0.001}
  });
}

function updateLayerColors() {
  if (state.level === 'counties') {
    if (state.overviewGeo && map.getSource('overview-munis')) map.getSource('overview-munis').setData(decorateGeo(state.overviewGeo, 'municipality'));
    if (state.geo && map.getSource('areas')) map.getSource('areas').setData(decorateGeo(state.geo, 'county'));
    return;
  }
  if (!state.geo || !map.getSource('areas')) return;
  const kind = state.level === 'municipalities' ? 'municipality' : 'district';
  map.getSource('areas').setData(decorateGeo(state.geo, kind));
}

function bboxOfFeature(feature) {
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  const visit = c => {
    if (typeof c[0] === 'number') { minX=Math.min(minX,c[0]); maxX=Math.max(maxX,c[0]); minY=Math.min(minY,c[1]); maxY=Math.max(maxY,c[1]); return; }
    c.forEach(visit);
  };
  visit(feature.geometry.coordinates);
  return [[minX,minY],[maxX,maxY]];
}

function fitFeature(feature, padding=52, maxZoom=9.5) {
  map.fitBounds(bboxOfFeature(feature), {padding, duration:900, essential:true, maxZoom});
}

function setDistrictDoubleClick(enabled) {
  if (!map.doubleClickZoom) return;
  if (enabled) map.doubleClickZoom.enable();
  else map.doubleClickZoom.disable();
}

async function loadCounties(animate=true) {
  state.level='counties'; state.county=null; state.municipality=null;
  closeMapPanels(); renderDistrictList();
  setDistrictDoubleClick(true);

  // Länsfilen finns även i v1. Hämta den först så kartan aldrig behöver bli helt tom.
  const counties = await fetchJson('/api/geo/counties');
  let municipalities = null;
  try {
    municipalities = await fetchJson('/api/geo/municipalities/all');
  } catch (err) {
    console.warn('Kunde inte hämta rikstäckande kommunlager:', err);
  }

  if (municipalities?.features?.length) {
    installNationalLayers(counties, municipalities);
    $('mapHint').textContent='Alla kommungränser visas · klicka på ett län för att zooma in';
  } else {
    // Vanligaste orsaken är att en äldre backend fortfarande kör på port 8765.
    installAreaLayer(counties, 'county');
    $('mapHint').textContent='Länskarta visas · starta om programmet för kommungränser i Sverigevyn';
    showFrontendError('Kommunlagret kunde inte hämtas. Om du nyss uppdaterade programmet kör sannolikt en äldre Valvaka-backend fortfarande på port 8765. Stäng den gamla terminalen med Ctrl+C och starta appen igen.');
  }

  renderBreadcrumbs(); renderSelection(null); renderDistrictList();
  if (animate) map.fitBounds([[10.4,54.6],[24.9,69.4]], {padding:35,duration:950,essential:true});
}

async function loadMunicipalities(countyFeature) {
  const code = String(countyFeature.properties.code);
  state.level='municipalities'; state.county={code,name:countyFeature.properties.name}; state.municipality=null;
  setDistrictDoubleClick(true);
  const geo = await fetchJson(`/api/geo/municipalities?county=${code}`);
  installAreaLayer(geo, 'municipality', countyFeature); fitFeature(countyFeature,48); renderBreadcrumbs(); renderSelection(countyFeature); renderDistrictList(); closeMapPanels();
  $('mapHint').textContent='Kommunen färgas när minst ett valdistrikt har rapporterat · klicka för valdistrikt';
}

async function loadDistricts(muniFeature) {
  const code = String(muniFeature.properties.code);
  state.level='districts'; state.municipality={code,name:muniFeature.properties.name};
  setDistrictDoubleClick(false);
  const geo = await fetchJson(`/api/geo/districts?municipality=${code}`);
  installAreaLayer(geo, 'district', muniFeature); fitFeature(muniFeature,48,9.8); renderBreadcrumbs(); renderSelection(muniFeature); renderDistrictList(); closeMapPanels();
  $('mapHint').textContent='Valdistriktsnamn visas på kartan · använd listan eller sök om ett distrikt är litet';
}

function renderBreadcrumbs() {
  const b = $('breadcrumbs');
  const parts = [{label:'Sverige', action:()=>loadCounties()}];
  if (state.county) parts.push({label:state.county.name, action: async()=>{
    const all = await fetchJson('/api/geo/counties');
    const f=all.features.find(x=>String(x.properties.code)===String(state.county.code)); if(f) loadMunicipalities(f);
  }});
  if (state.municipality) parts.push({label:state.municipality.name, action:null});
  b.innerHTML='';
  parts.forEach((p,i)=>{
    const btn=document.createElement('button'); btn.className='crumb'+(i===parts.length-1?' current':''); btn.textContent=p.label;
    if (p.action && i!==parts.length-1) btn.onclick=p.action;
    b.appendChild(btn);
  });
}

function areaBucketAndCode(feature) {
  if (!feature) return [null,null];
  const code=String(feature.properties.code || '');
  const bucket = code.length===2 ? state.results.counties : code.length===4 ? state.results.municipalities : state.results.districts;
  return [bucket,code];
}

function renderSelection(feature) {
  if (!feature) {
    $('selectionTitle').textContent='Sverige';
    $('selectionSubtitle').textContent='Alla 290 kommuner visas på Sverigekartan.';
    $('areaProgress').textContent='—'; $('areaLeader').textContent='—';
    return;
  }
  const [bucket,code]=areaBucketAndCode(feature); const r=(bucket||{})[code]||{};
  $('selectionTitle').textContent=feature.properties.name;
  const type = code.length===2?'Län':code.length===4?'Kommun':'Valdistrikt';
  const hasAny = Number(r.reported || 0) > 0;
  const status = r.complete ? 'Färdigräknat' : hasAny ? 'Räkning pågår' : 'Inga rapporterade resultat ännu';
  $('selectionSubtitle').textContent=`${type} · ${status}`;
  $('areaProgress').textContent = r.total ? `${r.reported || 0} / ${r.total}` : (r.complete?'Klart':'—');
  $('areaLeader').innerHTML = r.leader ? `<span style="color:${partyColor(r.leader)}">${esc(r.leader)}</span>` : '—';
}

function renderResultTiles(shares) {
  $('resultTiles').innerHTML = PARTY_ORDER.map(p=>{
    const s = shares[p];
    const color = partyColor(p);
    const empty = s == null;
    return `<div class="result-tile" title="${esc(p)}">
      <div class="result-party" style="background:${color}">${esc(p)}</div>
      <div class="result-share${empty?' empty':''}">${empty?'—':fmtPct(s)}</div>
    </div>`;
  }).join('');
}

function renderMandates(national) {
  const mandates = national.mandates && Object.keys(national.mandates).length ? national.mandates : (national.mandate_projection || {});
  const source = national.mandates && Object.keys(national.mandates).length ? (national.mandates_source || 'Valmyndigheten') : (Object.keys(mandates).length ? 'PROGNOS' : '');
  $('mandateLabel').textContent = source === 'PROGNOS' ? 'MANDATPROGNOS' : 'MANDAT';
  $('mandateSource').textContent = source && source !== 'PROGNOS' ? source.toUpperCase() : '';

  const totalAssigned = Object.values(mandates).reduce((a,b)=>a+Number(b||0),0);
  if (!totalAssigned) {
    $('blocBar').innerHTML='<div class="board-empty">Väntar på tillräckligt resultatunderlag…</div>';
    $('mandateSegments').innerHTML='';
    return;
  }

  const left = PARTY_ORDER.filter(p=>LEFT_BLOCK.has(p)).reduce((s,p)=>s+Number(mandates[p]||0),0);
  const right = PARTY_ORDER.filter(p=>RIGHT_BLOCK.has(p)).reduce((s,p)=>s+Number(mandates[p]||0),0);
  const other = Math.max(0, 349-left-right);
  $('blocBar').innerHTML = `
    <div class="bloc-part bloc-left" style="width:${left/349*100}%">${left}</div>
    <div class="bloc-part bloc-right" style="width:${right/349*100}%">${right}</div>
    ${other?`<div class="bloc-part" style="width:${other/349*100}%;background:#64748b">${other}</div>`:''}
    <div class="majority-line" title="175 mandat krävs för majoritet"></div>`;

  const light = new Set(['MP','C','M','SD']);
  $('mandateSegments').innerHTML = PARTY_ORDER.map(p=>{
    const m = Number(mandates[p]||0);
    if (!m) return '';
    return `<div class="mandate-segment${light.has(p)?' light-text':''}" style="width:${m/349*100}%;background:${partyColor(p)}" title="${esc(p)}: ${m} mandat">${m}</div>`;
  }).join('');
}

function renderNational() {
  const n=state.results.national||{};
  const rep=Number(n.reported||0), total=Number(n.total||0), pct=total?rep/total*100:0;
  $('countedNumber').textContent=total?`${fmtInt(rep)} / ${fmtInt(total)}`:'Hämtar…';
  $('progressBar').style.width=`${Math.min(100,pct)}%`;
  $('progressText').textContent=`${fmtPct(pct)} % av kartlagda valdistrikt`;
  $('boardCountNumber').textContent=total?`${fmtInt(rep)} / ${fmtInt(total)}`:'Hämtar…';
  $('boardCountFill').style.width=`${Math.min(100,pct)}%`;
  renderResultTiles(n.shares||{});
  renderMandates(n);
}

function renderLegend() {
  $('legend').innerHTML=PARTY_ORDER.filter(p=>state.colors[p]).map(p=>`<div class="legend-item"><span class="legend-dot" style="background:${state.colors[p]}"></span>${p}</div>`).join('')+
  `<div class="legend-item"><span class="legend-dot" style="background:#2d3a48"></span>Ingen rapport</div>`;
}

function formatTime(ts) {
  if (!ts) return 'Väntar på data…';
  return 'Senast uppdaterad ' + new Date(ts*1000).toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
}

function districtDetails(feature) {
  const code=String(feature.properties.code || '');
  return (state.results.districts||{})[code] || {};
}

function showDistrictModal(feature) {
  state.modalFeature = feature;
  const r = districtDetails(feature);
  const votes = r.votes || {};
  const totalVotes = Number(r.total_votes || Object.values(votes).reduce((a,b)=>a+Number(b||0),0));
  $('districtModalTitle').textContent = feature.properties.name || `Valdistrikt ${feature.properties.code}`;
  $('districtModalMeta').textContent = `${feature.properties.municipality_name || state.municipality?.name || ''} · ${feature.properties.county_name || state.county?.name || ''} · Kod ${feature.properties.code}`;
  $('districtStatus').textContent = r.complete ? 'Färdigräknat' : 'Ej färdigräknat';
  $('districtLeader').innerHTML = r.leader ? `<span style="color:${partyColor(r.leader)}">${esc(r.leader)}</span>` : '—';
  $('districtVotes').textContent = totalVotes ? fmtInt(totalVotes) : '—';

  const rows = Object.entries(votes).sort((a,b)=>Number(b[1])-Number(a[1]));
  $('districtPartyRows').innerHTML = rows.length ? rows.map(([p,v])=>{
    const share = totalVotes ? Number(v)/totalVotes*100 : 0;
    return `<div class="district-party-row">
      <div class="district-party-code" style="color:${partyColor(p)}">${esc(p)}</div>
      <div class="district-party-track"><div class="district-party-fill" style="width:${share}%;background:${partyColor(p)}"></div></div>
      <div class="district-party-votes">${fmtInt(v)}</div>
      <div class="district-party-share">${fmtPct(share)} %</div>
    </div>`;
  }).join('') : '<div class="muted">Inga röster har publicerats för valdistriktet ännu.</div>';

  $('districtModal').classList.remove('hidden');
}

function closeDistrictModal() {
  state.modalFeature = null;
  $('districtModal').classList.add('hidden');
}

function tooltipText(feature) {
  const [bucket,code]=areaBucketAndCode(feature); const r=(bucket||{})[code]||{};
  if (code.length === 8) return r.complete ? `Klart · ${r.leader||'—'} leder` : 'Ej färdigräknat';
  const rep=Number(r.reported||0), total=Number(r.total||0);
  if (!rep) return 'Inga räknade valdistrikt ännu';
  return `${rep}/${total||'?'} distrikt · ${r.leader||'—'} leder${r.complete?' · klart':''}`;
}

async function fetchResults() {
  try {
    const payload=await fetch('/api/results',{cache:'no-store'}).then(r=>r.json());
    state.results=payload.results||state.results;
    state.lastStatus=payload.status||{};
    renderNational(); updateLayerColors(); renderDistrictList();
    if (state.modalFeature && !$('districtModal').classList.contains('hidden')) showDistrictModal(state.modalFeature);
    $('updatedText').textContent=formatTime(payload.status.last_updated);
    $('liveLabel').textContent=payload.status.last_updated?(payload.status.demo?'DEMO':'LIVE'):(payload.status.updating?'HÄMTAR':'STARTAR');
    $('refreshBtn').disabled=!!payload.status.updating;
    const err=payload.status.error;
    $('errorCard').classList.toggle('hidden',!err); $('errorText').textContent=err||'';
    const stageNames={idle:'Väntar',index:'Kontrollerar Valmyndigheten',download:'Hämtar resultatfil',parse:'Tolkar valdistrikt',aggregate:'Summerar resultat',save:'Sparar resultat',ready:'Live-data klar',error:'Fel'};
    const stage=payload.status.stage||'idle';
    const updating=!!payload.status.updating;
    const checked=payload.status.last_checked ? new Date(payload.status.last_checked*1000).toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit',second:'2-digit'}) : '—';
    const duration=payload.status.last_duration!=null ? `${Number(payload.status.last_duration).toFixed(1).replace('.',',')} s` : '—';
    $('connectionText').textContent = err ? err : `${stageNames[stage]||stage}${updating?'…':''} · senast kontrollerad ${checked} · senaste körning ${duration}`;
  } catch(e) {
    $('errorCard').classList.remove('hidden'); $('errorText').textContent='Kunde inte läsa lokal backend.';
  }
}

function bindMapEvents() {
  map.on('click','areas-hit', async e=>{
    if (state.level==='districts') return; // district clicks use a larger touch target below
    const feature=e.features?.[0]; if(!feature) return;
    if(state.level==='counties') await loadMunicipalities(feature);
    else if(state.level==='municipalities') { state.suppressDistrictClickUntil=Date.now()+1100; await loadDistricts(feature); }
  });

  // On phones a tiny urban district may only be a few pixels wide. Query a
  // 36x36 px touch box, while preferring an exact polygon hit when possible.
  map.on('click', e=>{
    if (state.level!=='districts' || !map.getLayer('areas-hit')) return;
    if (Date.now() < state.suppressDistrictClickUntil) return;
    const exact=map.queryRenderedFeatures(e.point,{layers:['areas-hit']});
    let features=exact;
    if (!features.length) {
      const r=18, p=e.point;
      features=map.queryRenderedFeatures([[p.x-r,p.y-r],[p.x+r,p.y+r]],{layers:['areas-hit']});
    }
    if (!features.length) return;
    let feature=features[0];
    if (features.length>1) {
      feature=[...features].sort((a,b)=>{
        const pa=map.project(featureLabelPoint(a)), pb=map.project(featureLabelPoint(b));
        const da=(pa.x-e.point.x)**2+(pa.y-e.point.y)**2;
        const db=(pb.x-e.point.x)**2+(pb.y-e.point.y)**2;
        return da-db;
      })[0];
    }
    focusDistrict(feature,false);
    showDistrictModal(feature);
  });

  if (window.matchMedia('(hover:hover) and (pointer:fine)').matches) {
    map.on('mousemove','areas-hit', e=>{
      map.getCanvas().style.cursor='pointer';
      const f=e.features?.[0]; if(!f) return;
      const html=`<div class="popup-name">${esc(f.properties.name)}</div><div class="popup-sub">${esc(tooltipText(f))}</div>`;
      if(!state.popup) state.popup=new maplibregl.Popup({closeButton:false,closeOnClick:false,offset:10});
      state.popup.setLngLat(e.lngLat).setHTML(html).addTo(map);
    });
    map.on('mouseleave','areas-hit', ()=>{ map.getCanvas().style.cursor=''; if(state.popup){state.popup.remove();state.popup=null;} });
  }
}

function setupMapTools() {
  $('searchBtn')?.addEventListener('click',()=>{
    const panel=$('searchPanel');
    const opening=panel.classList.contains('hidden');
    closeMapPanels();
    if (opening) { panel.classList.remove('hidden'); $('mapSearchInput').value=''; renderSearchResults(''); setTimeout(()=>$('mapSearchInput').focus(),40); }
  });
  $('searchCloseBtn')?.addEventListener('click',()=>$('searchPanel').classList.add('hidden'));
  $('mapSearchInput')?.addEventListener('input',e=>renderSearchResults(e.target.value));
  $('districtListBtn')?.addEventListener('click',()=>{
    const panel=$('districtListPanel'); const opening=panel.classList.contains('hidden');
    closeMapPanels(); if(opening) panel.classList.remove('hidden');
  });
  $('districtListCloseBtn')?.addEventListener('click',()=>$('districtListPanel').classList.add('hidden'));
}

function setSidebarOpen(open) {
  document.body.classList.toggle('sidebar-open', !!open);
  $('mobileInfoBtn')?.setAttribute('aria-expanded', open ? 'true' : 'false');
}

$('mobileInfoBtn')?.addEventListener('click', ()=>setSidebarOpen(!document.body.classList.contains('sidebar-open')));
$('sidebarCloseBtn')?.addEventListener('click', ()=>setSidebarOpen(false));
$('sidebarScrim')?.addEventListener('click', ()=>setSidebarOpen(false));

// Android/Chrome ändrar den synliga viewporten när adressfältet visas/döljs.
// MapLibre behöver då få en resize-signal för att kartan ska fylla ytan korrekt.
let resizeTimer = null;
function scheduleMapResize() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(()=>{ try { map.resize(); } catch (_) {} }, 90);
}
window.addEventListener('resize', scheduleMapResize, {passive:true});
window.addEventListener('orientationchange', ()=>setTimeout(scheduleMapResize, 160), {passive:true});
if (window.visualViewport) window.visualViewport.addEventListener('resize', scheduleMapResize, {passive:true});

map.on('load', async()=>{
  try {
    const boot=await fetchJson('/api/bootstrap', {cache:'no-store'});
    state.colors=boot.party_colors||{};
    renderLegend();
    setupMapTools();

    // Ett versionsfel betyder oftast att den gamla Python-processen fortfarande äger port 8765.
    if (boot.app_version !== FRONTEND_VERSION) {
      showFrontendError(`Frontend v${FRONTEND_VERSION} matchar inte backend${boot.app_version ? ` v${boot.app_version}` : ''}. Stäng appen helt och öppna den igen.`);
    }

    await fetchResults();
    await loadCounties(false);
    bindMapEvents();
    map.fitBounds([[10.4,54.6],[24.9,69.4]], {padding:35,duration:850,essential:true});
    setInterval(fetchResults, 15000);
  } catch (err) {
    console.error(err);
    showFrontendError(`Kartan kunde inte startas: ${err.message || err}`);
    $('mapHint').textContent='Kartan kunde inte laddas';
  }
});

$('refreshBtn').addEventListener('click',async()=>{
  if ($('refreshBtn').disabled) return;
  $('refreshBtn').disabled=true;
  $('refreshBtn').style.transform='rotate(180deg)';
  await fetch('/api/refresh',{method:'POST'}).catch(()=>{});
  setTimeout(async()=>{await fetchResults(); $('refreshBtn').style.transform='';},900);
});

$('districtModalClose').addEventListener('click', closeDistrictModal);
$('districtModal').addEventListener('click', e=>{ if (e.target === $('districtModal')) closeDistrictModal(); });
document.addEventListener('keydown', e=>{ if(e.key==='Escape'){ closeDistrictModal(); setSidebarOpen(false); } });
